package com.ilstu.edu;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

/**
 * This is a class which tests user interface of 
 * ngcoursereview named project
 * 
 * @author Aayush Agrawal
 */



public class UITesting {




	WebDriver driver;
	
   /**
	 * Loads browser in Java
	 * and perform maximization and timeout
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception{
		System.out.println("-----------NGCOURSEREVIEW functionalities--------");
		
		
		System.out.println("\nInitializing browser...");
		System.out.println("-------------------------------------------");
		getWebDriver(BrowserType.FIREFOX);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("Testing UI...");
		
		
	}
	
	/**
	 * Checks the navigation and see if each section
	 * is accessible from whole page and the project link too
	 * 
	 * @throws Exception
	 */
	@Test
	public void navigationTest() throws Exception{
		//open the web-site login page
		driver.get("http://localhost:8080/ngcoursereview/index.html");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@href='#authors']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@href='#macbook']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@href='#summary']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[text()='GitHub Link']")).click();
		Thread.sleep(2000);
		
		driver.navigate().back();

		
}

	
	/**
	 * Logs into the system and
	 * check the functionality performed and then
	 * Logout
	 * 
	 * @throws Exception
	 */
	
	@Test
	public void basicFunctionalities() throws Exception{
		
		driver.get("http://localhost:8080/ngcoursereview/index.html");
		driver.findElement(By.xpath("//a[@href='#summary']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//a[@href='#/register']")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.id("//a[@href='#/login']")).click();
		Thread.sleep(3000);
		
		System.out.println("verifying userid and password...");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("aayush.ag85@gmail.com");
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("123456");
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.id("booksButton")).click();
		Thread.sleep(3000);
		
		Select s=new Select(driver.findElement(By.id("course")));
		s.selectByIndex(1);
		Thread.sleep(3000);
		
		driver.findElement(By.id("addReviewButton")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("booksButton")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("reviewsButton")).click();
		Thread.sleep(3000);		
		
		driver.findElement(By.id("logoutButton")).click();
		Thread.sleep(4000);
	
}
	
	/**
	 * Closes the browser
	 * 
	 */
	
	@After
	public void tearDown(){
		System.out.println("Testing completed");
		driver.quit();
	}
	

	/**
	 * Supporting multiple browser types
	 * 
	 * @param browsertype
	 */
	
	public void getWebDriver(BrowserType browsertype)
	{
		switch(browsertype)
		{
		case FIREFOX:
			driver=new FirefoxDriver();
			break;
		case IE:
			DesiredCapabilities iecap=DesiredCapabilities.internetExplorer();
			iecap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			File f1=new File("E:\\Lectures\\Testing\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", f1.getAbsolutePath());
			driver=new InternetExplorerDriver(iecap);
			
			break;
		case CHROME:
			driver=new ChromeDriver();
			break;
		case HTMLUNIT:
			driver=new HtmlUnitDriver();
			break;
			default:
				throw new RuntimeException("Browser not supported");
		}
	}
	
	/**
	 * for mutiple browser support
	 * 
	 * @author Aayush
	 *
	 */
	public enum BrowserType{
			FIREFOX, IE, CHROME, HTMLUNIT
		}


}
