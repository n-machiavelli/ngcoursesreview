package com.ilstu.edu;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

/**
 * This is a class which tests user interface of 
 * ngcoursereview named project
 * 
 * @author Aayush Agrawal
 */



public class UITesting {




	WebDriver driver;
	String website="http://localhost:8080/ngcoursereview/index.html";
	int clicks=0;
	int pagecount=0;
   /**
	 * Loads browser in Java
	 * and perform maximization and timeout
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception{
		System.out.println("-----------NGCOURSEREVIEW functionalities--------");
		
		
		System.out.println("\nInitializing browser...");
		System.out.println("-------------------------------------------");
		getWebDriver(BrowserType.FIREFOX);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("Testing UI...");
		
		
	}
	
	/**
	 * Checks the navigation and see if each section
	 * is accessible from whole page and the project link too
	 * 
	 * @throws Exception
	 */
	@Test
	public void navigationTest() throws Exception{
		//open the web-site login page
		driver.get(website);
		Thread.sleep(2000);
		pagecount++;
		
		driver.findElement(By.xpath("//a[@href='#authors']")).click();
		Thread.sleep(2000);
		clicks++;
		pagecount++;
		
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		Thread.sleep(2000);
		clicks++;
		
		driver.findElement(By.xpath("//a[@href='#macbook']")).click();
		Thread.sleep(2000);
		clicks++;
		pagecount++;
		
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		Thread.sleep(2000);
		clicks++;
		
		driver.findElement(By.xpath("//a[@href='#summary']")).click();
		Thread.sleep(2000);
		clicks++;
		pagecount++;
		
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		Thread.sleep(2000);
		clicks++;
		
		
		driver.findElement(By.xpath("//a[text()='Help']")).click();
		Thread.sleep(2000);
		clicks++;
		pagecount++;
		
		driver.navigate().back();
		Thread.sleep(2000);
		clicks++;
		
		driver.findElement(By.xpath("//a[text()='GitHub Link']")).click();
		Thread.sleep(2000);
		clicks++;
		pagecount++;
		
		driver.navigate().back();
		clicks++;
		
		System.out.println("For a "+pagecount+" website you are having "+clicks+" clicks");
		
		//Condition for websites UI to be friendly.
		if(clicks<2*pagecount)
		{
			assertTrue(true);
		}
		else
		{
			assertTrue(false);
		}
		
		
		
		
}

	
		
	/**
	 * Closes the browser
	 * 
	 */
	
	@After
	public void tearDown(){
		System.out.println("Testing completed");
		driver.quit();
	}
	

	/**
	 * Supporting multiple browser types
	 * 
	 * @param browsertype
	 */
	
	public void getWebDriver(BrowserType browsertype)
	{
		switch(browsertype)
		{
		case FIREFOX:
			driver=new FirefoxDriver();
			break;
		case IE:
			DesiredCapabilities iecap=DesiredCapabilities.internetExplorer();
			iecap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			File f1=new File("E:\\Lectures\\Testing\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", f1.getAbsolutePath());
			driver=new InternetExplorerDriver(iecap);
			
			break;
		case CHROME:
			driver=new ChromeDriver();
			break;
		case HTMLUNIT:
			driver=new HtmlUnitDriver();
			break;
			default:
				throw new RuntimeException("Browser not supported");
		}
	}
	
	/**
	 * for mutiple browser support
	 * 
	 * @author Aayush
	 *
	 */
	public enum BrowserType{
			FIREFOX, IE, CHROME, HTMLUNIT
		}


}
