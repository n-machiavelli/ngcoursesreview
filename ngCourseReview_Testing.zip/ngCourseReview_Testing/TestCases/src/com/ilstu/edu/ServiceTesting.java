package com.ilstu.edu;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

/**
 * This is a class which tests functionality of 
 * ngcoursereview response timings and synchronization
 * of the application
 * 
 * @author Aayush Agrawal
 */



public class ServiceTesting {




	WebDriver driver;
	String website="http://localhost:8080/ngcoursereview/index.html";
	String id="aayush.ag85@gmail.com";
	String password="123456";
	
   /**
	 * Loads browser in Java
	 * and perform maximization and timeout
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception{
		System.out.println("-----------NGCOURSEREVIEW functionalities--------");
		
		
		System.out.println("\nInitializing browser...");
		System.out.println("-------------------------------------------");
		getWebDriver(BrowserType.FIREFOX);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get(website);
		driver.findElement(By.xpath("//a[@href='#summary']")).click();
		Thread.sleep(2000);
		
		System.out.println("verifying userid and password...");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(id);
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(3000);
		System.out.println("Login successfull");
		
		Select s=new Select(driver.findElement(By.id("course")));
		s.selectByIndex(1);
		Thread.sleep(3000);
		System.out.println("course selected");
		System.out.println("Testing Functionality...");
		
	}
	
		
	/**
	 * Checks wheather the ebay service
	 * replies in a period of 1sec or not
	 * timeout is set to 3 sec and wait for 2 sec
	 * Thus, for success it should reply in 1 sec
	 * 
	 * @throws Exception
	 */
	
	@Test(timeout=3000)
	public void ebayServiceResponseTesting() throws Exception{
		
		driver.findElement(By.id("booksButton")).click();
		Thread.sleep(2000);
		assertTrue(driver.getPageSource().contains("A Brief History of Time by Stephen Hawking."));
	}
	/**
	 * Checks wheather our own service
	 * replies in a period of 1sec or not
	 * timeout is set to 3 sec and wait for 2 sec
	 * Thus, for success it should reply in 1 sec
	 * 
	 * @throws Exception
	 */

	@Test(timeout=3000)
	public void ourAPIServiceResponseTesting() throws Exception{
		driver.findElement(By.id("reviewsButton")).click();
		Thread.sleep(2000);		
		assertTrue(driver.getPageSource().contains("hkkjjkhkj"));
	}
	
	/**
	 * Checks synchronization of the application
	 * the review is add by the user is immediately available
	 * to view or not
	 * 
	 * @throws Exception
	 */
	
	@Test
	public void synchronizationTesting() throws Exception{
		//select any specific course
		//use 1(web development) or 4(Data communication) in index
		Select s=new Select(driver.findElement(By.id("course")));
		s.selectByIndex(1);
		Thread.sleep(3000);
		
		//select add review
		driver.findElement(By.id("addReviewButton")).click();
		Thread.sleep(2000);
		
		//Adding review body filling all values
		driver.findElement(By.xpath("//input[@name='reviewTitle']")).sendKeys("Very nice course");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='bookTitle']")).sendKeys("Data Communication Networks");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//textarea[@name='reviewBody']")).sendKeys("Learned a lot and the instructor is very helpful");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@value='Add Review']")).click();
		Thread.sleep(2000);	
		
		//going to view review section
		driver.findElement(By.id("reviewsButton")).click();
		Thread.sleep(2000);
		
		//checking if review available or not
		assertTrue(driver.getPageSource().contains("Very nice course"));
		
	}
	
	/**
	 * Closes the browser
	 * @throws InterruptedException 
	 * 
	 */
	
	@After
	public void tearDown() throws InterruptedException{
		driver.findElement(By.id("logoutButton")).click();
		Thread.sleep(4000);
		System.out.println("Testing completed");
		driver.quit();
	}
	

	/**
	 * Supporting multiple browser types
	 * 
	 * @param browsertype
	 */
	
	public void getWebDriver(BrowserType browsertype)
	{
		switch(browsertype)
		{
		case FIREFOX:
			driver=new FirefoxDriver();
			break;
		case IE:
			DesiredCapabilities iecap=DesiredCapabilities.internetExplorer();
			iecap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			File f1=new File("E:\\Lectures\\Testing\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", f1.getAbsolutePath());
			driver=new InternetExplorerDriver(iecap);
			
			break;
		case CHROME:
			driver=new ChromeDriver();
			break;
		case HTMLUNIT:
			driver=new HtmlUnitDriver();
			break;
			default:
				throw new RuntimeException("Browser not supported");
		}
	}
	
	/**
	 * for mutiple browser support
	 * 
	 * @author Aayush
	 *
	 */
	public enum BrowserType{
			FIREFOX, IE, CHROME, HTMLUNIT
		}


}

