1. Java 7 installed
2. Junit4 library included
3. Selenium Jar included as external Jar provided with the attachment
4. Firefox installed on the machine

Run test cases using Eclipse Junit Launcher

Tested Application requirement

Is currently on wamp server and running at localhost port 8080 which can be changed 
from a variable name website in the programs.